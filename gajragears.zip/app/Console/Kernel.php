<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use App\Console\Commands\EveryNight;
use App\Console\Commands\AutoPunchOut;
use App\Console\Commands\AddressUpdate;
class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        //$schedule->command(EveryNight::class, ['--force'])->dailyAt('13:00');
        $schedule->command(EveryNight::class)->timezone('Asia/Kolkata')->dailyAt('23:00');
        $schedule->command(AutoPunchOut::class)->timezone('Asia/Kolkata')->dailyAt('22:30');
        $schedule->command(AddressUpdate::class)->timezone('Asia/Kolkata')->everyFourHours();
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
