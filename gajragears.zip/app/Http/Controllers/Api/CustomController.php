<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

use Validator;
use Gate;
use App\Models\{CustomerType , Customers};

class CustomController extends Controller
{
    public function __construct()
    {
        
        $this->successStatus = 200;
        $this->created = 201;
        $this->accepted = 202;
        $this->noContent = 204;
        $this->badrequest = 400;
        $this->unauthorized = 401;
        $this->notFound = 404;
        $this->notactive = 406;
        $this->internalError = 500;
    }
    public function getCustomerTypeList(Request $request)
    {
        try
        { 
            $pageSize = $request->input('pageSize');
            $query = CustomerType::where(function ($query) {
                                        $query->where('active', '=', 'Y');
                                    })->select('id','customertype_name');

            $db_data = (!empty($pageSize)) ? $query->paginate($pageSize) : $query->get();
            $data = collect([]);
            if($db_data->isNotEmpty())
            {
                foreach ($db_data as $key => $value) {
                    $data->push([
                        'customertype' => isset($value['id']) ? $value['id'] : 0,
                        'customertype_name' => isset($value['customertype_name']) ? $value['customertype_name'] : '',
                    ]);
                }
                return response()->json(['status' => 'success','message' => 'Data retrieved successfully.','data' => $data ], $this->successStatus);
            }
            return response(['status' => 'error', 'message' => 'No Record Found.', 'data' => $data ],200);  
            
        }
        catch(\Exception $e)
        {
            return response()->json(['status' => 'error','message' => $e->getMessage() ], $this->internalError);
        }        
    }
    public function getReportType(Request $request)
    {
        try
        { 
            $data = collect([
                'Field Activity',
                'Tour Programme'
            ]);
            if($data->isNotEmpty())
            {
                return response()->json(['status' => 'success','message' => 'Data retrieved successfully.','data' => $data ], $this->successStatus);
            }
            return response(['status' => 'error', 'message' => 'No Record Found.', 'data' => $data ],200); 
        }
        catch(\Exception $e)
        {
            return response()->json(['status' => 'error','message' => $e->getMessage() ], $this->internalError);
        }
    }
    public function getWorkType(Request $request)
    {
        try
        { 
            $data = collect([
              collect(["type" => 'Tour', "is_city" => true , "is_beat" => true , 'image' => true , 'summary' => true , 'city_required' => true , 'beat_required' => true ]), 
              collect(["type" => 'Office Work', "is_city" => true , "is_beat" => false , 'image' => true , 'summary' => true , 'city_required' => true , 'beat_required' => false ]), 
              collect(["type" => 'Suburban', "is_city" => true , "is_beat" => true , 'image' => true , 'summary' => true , 'city_required' => true , 'beat_required' => true ]), 
              collect(["type" => 'Central Market', "is_city" => true , "is_beat" => true , 'image' => true , 'summary' => true , 'city_required' => true , 'beat_required' => true ]), 
              collect(["type" => 'Holiday', "is_city" => false , "is_beat" => false , 'image' => false , 'summary' => false , 'city_required' => false , 'beat_required' => false ]), 
              collect(["type" => 'Leave', "is_city" => false , "is_beat" => false , 'image' => false , 'summary' => false , 'city_required' => false , 'beat_required' => false]),   
            ]);
            if($data->isNotEmpty())
            {
                return response()->json(['status' => 'success','message' => 'Data retrieved successfully.','data' => $data ], $this->successStatus);
            }
            return response(['status' => 'error', 'message' => 'No Record Found.', 'data' => $data ],200); 
        }
        catch(\Exception $e)
        {
            return response()->json(['status' => 'error','message' => $e->getMessage() ], $this->internalError);
        }
    }
    public function mobileNumberExists(Request $request)
    {
        try
        { 
            $validator = Validator::make($request->all(), [
                'mobile'  => 'required',
            ]); 
            if ($validator->fails()) {
                return response()->json(['status' => 'error','message' => $validator->messages()->all()],$this->badrequest);
            }
            $mobile = $request->input('mobile');
            if(strlen(preg_replace('/\s+/', '', $mobile)) == 10)
            {
                $mobile = '91'.preg_replace('/\s+/', '', $mobile);
            }
            if (!$customer = Customers::where('mobile', '=', $mobile)->exists()) {

               return response()->json(['status' => 'success','message' => 'Mobile number is available.'], $this->successStatus);
            }
            return response(['status' => 'error', 'message' => 'Mobile number already exists'],200);
        }
        catch(\Exception $e)
        {
            return response()->json(['status' => 'error','message' => $e->getMessage() ], $this->internalError);
        }
    }

    public function emailExists(Request $request)
    {
        try
        { 
            $validator = Validator::make($request->all(), [
                'email'  => 'required',
            ]); 
            if ($validator->fails()) {
                return response()->json(['status' => 'error','message' => $validator->messages()->all()],$this->badrequest);
            }
            $email = $request->input('email');
            if (!$customer = Customers::where('email', '=', $email)->exists()) {

               return response()->json(['status' => 'success','message' => 'Email is available.'], $this->successStatus);
            }
            return response(['status' => 'error', 'message' => 'Email already exists'],200);
        }
        catch(\Exception $e)
        {
            return response()->json(['status' => 'error','message' => $e->getMessage() ], $this->internalError);
        }
    }
}

