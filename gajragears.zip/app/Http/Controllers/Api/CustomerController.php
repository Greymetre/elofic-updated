<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;


use Validator;
use Gate;
use App\Models\Customers;
use App\Models\CustomerType;
use App\Models\Beat;
use App\Models\BeatSchedule;
use App\Models\BeatCustomer;
use App\Models\Attachment;
use App\Models\Address;
use App\Models\State;
use App\Models\CustomerDetails;
use App\Models\Pincode;
use App\Models\SurveyData;
use App\Models\Lead;
use App\Models\Order;
use App\Models\Sales;
use App\Models\CheckIn;
use App\Models\User;
use App\Models\UserActivity;
use App\Models\Tasks;
use App\Models\Wallet;
use App\Models\DealIn;

class CustomerController extends Controller
{
    public function __construct()
    {
        $this->customers = new Customers();
        $this->address = new Address();
        $this->successStatus = 200;
        $this->created = 201;
        $this->accepted = 202;
        $this->noContent = 204;
        $this->badrequest = 400;
        $this->unauthorized = 401;
        $this->notFound = 404;
        $this->notactive = 406;
        $this->internalError = 500;
        $this->path = 'customers';
    }

    public function storeCustomer(Request $request)
    {
        try
        { 
            $user = $request->user();
            $validator = Validator::make($request->all(), [
                'address' => 'nullable|min:2|max:100|string|regex:/[a-zA-Z0-9\s]+/',
                'mobile'  => 'required|numeric|unique:customers,mobile',
                // 'email'  => 'email|unique:customers,email',
                'customertype'       => 'nullable|exists:customer_types,id',
            ]); 
            if ($validator->fails()) {
                return response()->json(['status' => 'error','message' => $validator->messages()->all()],$this->badrequest);
            }
            //$request['fordelete'] = implode(',', $request->getContent());
           
            $name = explode(" ", $request['full_name']);
            $request['last_name'] = isset($request['last_name']) ? $request['last_name'] : array_pop($name);
            $request['first_name'] = isset($request['first_name']) ? $request['first_name'] : implode(" ", $name);
            $request['created_by'] = $user->id;
            
            $customertype = CustomerType::where('type_name', '=', 'retailer')->pluck('id')->first() ;
            $request['customertype'] = isset($request['customertype']) ? $request['customertype'] : $customertype;
            //$response =  $this->customers->save_data($request);
            if(strlen(preg_replace('/\s+/', '', $request['mobile'])) == 10)
            {
                $request['mobile'] = '91'.preg_replace('/\s+/', '', $request['mobile']);
            }

            if($request->file('image')){
                $image = $request->file('image');
                // $filename = 'punchin_'.autoIncrementId('Attendance', 'id');
                $filename = 'customer';
                $request['profile_image'] = fileupload($image, $this->path, $filename);
            }

            if($customer = Customers::updateOrCreate(['mobile' => $request['mobile']],[
                'active' => 'Y',
                'name' => !empty($request['name'])? ucfirst($request['name']):'',
                'first_name' => !empty($request['first_name'])? ucfirst($request['first_name']):'',
                'last_name' => !empty($request['last_name'])? ucfirst($request['last_name']):'',
                'mobile' => $request['mobile'],
                'email' => !empty($request['email'])? $request['email']:null,
                'password' => !empty($request['password'])? Hash::make($request['password']) :'',
                'notification_id' => !empty($request['notification_id'])? $request['notification_id']:'',
                'latitude' => !empty($request['latitude'])? $request['latitude']:null,
                'longitude' => !empty($request['longitude'])? $request['longitude']:null,
                'device_type' => !empty($request['device_type'])? ucfirst($request['device_type']):'',
                'gender' => !empty($request['gender'])? ucfirst($request['gender']):'',
                'customer_code' => !empty($request['customer_code'])? $request['customer_code']: '',
                'profile_image' =>  !empty($request['profile_image'])? $request['profile_image'] :'',
                'status_id' =>  !empty($request['status_id'])? $request['status_id'] :2,
                'customertype' =>  !empty($request['customertype'])? $request['customertype'] :1,
                'firmtype' =>  !empty($request['firmtype'])? $request['firmtype'] :null,
                'executive_id' =>  !empty($request['executive_id'])? $request['executive_id'] : $request['created_by'],
                'created_by' =>  !empty($request['created_by'])? $request['created_by'] :null,
                'manager_name' => !empty($request['manager_name'])? $request['manager_name'] :'',
                'manager_phone' => !empty($request['manager_phone'])? $request['manager_phone'] :'',
                'created_at' => getcurentDateTime(),
                'updated_at' => getcurentDateTime()
            ]))
            {
                // $useractivity = array(
                //     'userid' => $user->id, 
                //     'customer_id' => $customer->id,
                //     'latitude' => $request['latitude'], 
                //     'longitude' => $request['longitude'], 
                //     'type' => 'Counter Created',
                //     'description' => $user->name.' Created to '.$request['name'],
                // );
                // submitUserActivity($useractivity);
                $request['customer_id'] = $customer->id;
                $pincodes = Pincode::with('cityname','cityname.districtname')->where('pincode','=',$request['zipcode'])->first();
                $request['state_id'] = !empty($pincodes['cityname']['districtname']['state_id']) ? $pincodes['cityname']['districtname']['state_id']:$request['state_id'];
                $request['district_id'] = !empty($pincodes['cityname']['district_id']) ? $pincodes['cityname']['district_id'] : $request['district_id'];
                $request['city_id'] = !empty($pincodes['city_id']) ? $pincodes['city_id'] : $request['city_id'];
                $request['zipcode'] = !empty($request['pincode_id']) ? $request['pincode_id'] :$request['zipcode'] ;
                $request['pincode_id'] = !empty($pincodes['id']) ? $pincodes['id']:$request['pincode_id'];
                
                $request['country_id'] = !empty($request['country_id']) ? $request['country_id'] : State::where('id',$request['state_id'])->pluck('country_id')->first() ;
                $request['landmark'] = !empty($request['landmark']) ? $request['landmark'] :'' ;
                Address::updateOrCreate(['customer_id' => $request['customer_id']],[
                    'active'    => 'Y',
                    'customer_id'   =>  $request['customer_id'],
                    'address1' => !empty($request['address1']) ? $request['address1'] :'',
                    'address2' => !empty($request['address2']) ? $request['address2'] :'',
                    'landmark' => !empty($request['landmark']) ? $request['landmark'] :'',
                    'locality' => !empty($request['locality']) ? $request['locality'] :$request['landmark'],
                    'country_id' => !empty($request['country_id']) ? $request['country_id'] :null,
                    'state_id' => !empty($request['state_id']) ? $request['state_id'] :null,
                    'district_id' => !empty($request['district_id']) ? $request['district_id'] :null,
                    'city_id' => !empty($request['city_id']) ? $request['city_id'] :null,
                    'pincode_id' => !empty($request['pincode_id']) ? $request['pincode_id'] :null,
                    'zipcode' => !empty($request['zipcode']) ? $request['zipcode'] :'',
                    'created_by' => !empty($request['created_by']) ? $request['created_by'] :Auth::user()->id,
                    'created_at' => getcurentDateTime(),
                    'updated_at' => getcurentDateTime()
                ]);
                if($request->file('shopimage')){
                    $image = $request->file('shopimage');
                    $filename = 'customer';
                    $request['shop_image'] = fileupload($image, $this->path.'/shopimage', $filename);
                }

                if($request->file('visiting_card')){
                    $image = $request->file('visiting_card');
                    $filename = 'customer';
                    $request['visiting_image'] = fileupload($image, $this->path.'/visiting', $filename);
                }

                if($request->file('gstin_image')){
                    $image = $request->file('gstin_image');
                    $filename = 'customer';
                    $gstinimagepath = fileupload($image, $this->path.'/gstin', $filename);
                    Attachment::updateOrCreate([
                        'customer_id'   =>  $request['customer_id'],
                        'document_name' =>  'gstin'],[
                        'active'        => 'Y',
                        'file_path'     => $gstinimagepath,
                        'document_name' =>  'gstin', 
                        'customer_id' => $request['customer_id'],
                        'created_at' => getcurentDateTime(),
                        'updated_at' => getcurentDateTime()
                    ]);
                }

                if($request->file('pan_image')){
                    $image = $request->file('pan_image');
                    $filename = 'customer';
                    $panimagepath = fileupload($image, $this->path.'/pan', $filename);
                    Attachment::updateOrCreate([
                        'customer_id'   =>  $request['customer_id'],
                        'document_name' =>  'pan'],[
                        'active'        => 'Y',
                        'file_path'     => $panimagepath,
                        'document_name' =>  'pan', 
                        'customer_id' => $request['customer_id'],
                        'created_at' => getcurentDateTime(),
                        'updated_at' => getcurentDateTime()
                    ]);
                }

                if($request->file('aadhar_image')){
                    $image = $request->file('aadhar_image');
                    $filename = 'customer';
                    $aadharimagepath = fileupload($image, $this->path.'/aadhar', $filename);
                    Attachment::updateOrCreate([
                        'customer_id'   =>  $request['customer_id'],
                        'document_name' =>  'aadhar'],[
                        'active'        => 'Y',
                        'file_path'     => $aadharimagepath,
                        'document_name' =>  'aadhar', 
                        'customer_id' => $request['customer_id'],
                        'created_at' => getcurentDateTime(),
                        'updated_at' => getcurentDateTime()
                    ]);
                }

                if($request->file('other_image')){
                    $image = $request->file('other_image');
                    $filename = 'customer';
                    $otherimagepath = fileupload($image, $this->path.'/other', $filename);
                    Attachment::updateOrCreate([
                        'customer_id'   =>  $request['customer_id'],
                        'document_name' =>  'other'],[
                        'active'        => 'Y',
                        'file_path'     => $otherimagepath,
                        'document_name' =>  'other', 
                        'customer_id' => $request['customer_id'],
                        'created_at' => getcurentDateTime(),
                        'updated_at' => getcurentDateTime()
                    ]);
                }

                CustomerDetails::updateOrCreate(['customer_id' => $request['customer_id']],[
                    'active'        => 'Y',
                    'customer_id'   => isset($request['customer_id'])? $request['customer_id']:null,
                    'gstin_no'      => isset($request['gstin_no'])? ucfirst($request['gstin_no']):'',
                    'pan_no'        => isset($request['pan_no'])? ucfirst($request['pan_no']):'',
                    'aadhar_no'     => isset($request['aadhar_no'])? ucfirst($request['aadhar_no']):'',
                    'otherid_no'    => isset($request['otherid_no'])? ucfirst($request['otherid_no']):'',
                    'enrollment_date' => isset($request['enrollment_date'])? $request['enrollment_date']:null,
                    'approval_date'  => isset($request['approval_date'])? $request['approval_date']:null,
                    'shop_image' => isset($request['shop_image'])? $request['shop_image']:'',
                    'visiting_card' => isset($request['visiting_image'])? $request['visiting_image']:'',
                    'grade'     => isset($request['grade'])? $request['grade'] :'',
                    'visit_status'     => isset($request['status_type'])? $request['status_type']:'',
                    'created_at'    => getcurentDateTime(),
                ]);


                if($request['beat_id'])
                {
                    $beats = BeatCustomer::updateOrCreate(['customer_id' => $request['customer_id']],[
                        'active' => 'Y',
                        'beat_id' => $request['beat_id'],
                        'customer_id' => $request['customer_id'],
                        'created_at' => getcurentDateTime(),
                    ]);
                }
                if($request['survey'])
                {
                    $surveydetail = collect([]);
                    $surveyqus = json_decode($request['survey'], true);
                    foreach ($surveyqus as $key => $rows) {
                        SurveyData::updateOrCreate([
                            'customer_id' => $request['customer_id'],
                            'field_id' => $rows['field_id']
                            ],[
                            'customer_id'   => isset($request['customer_id'])? $request['customer_id']:null,
                            'field_id' => isset($rows['field_id']) ? $rows['field_id'] :null,
                            'value' => isset($rows['value']) ? $rows['value'] :'',
                            'created_by' => isset($request['created_by']) ? $request['created_by'] :Auth::user()->id,
                            'created_at' => getcurentDateTime(),
                        ]);
                    }

                    // if($surveydetail->isNotEmpty())
                    // {
                    //     SurveyData::insert($surveydetail->toArray());
                    // }
                }
                if($request['dealing'])
                {
                    $dealings = json_decode($request['dealing'], true);
                    foreach ($dealings as $key => $deal) {
                        DealIn::updateOrCreate([
                            'customer_id' => $request['customer_id'],
                            'types' => $deal['types']
                            ],[
                            'customer_id'   => !empty($request['customer_id'])? $request['customer_id']:null,
                            'types' => !empty($deal['types']) ? $deal['types'] :'',
                            'hcv' => isset($deal['hcv']) ? $deal['hcv'] : false, 
                            'mav' => isset($deal['mav']) ? $deal['mav'] : false, 
                            'lmv' => isset($deal['lmv']) ? $deal['lmv'] : false, 
                            'lcv' => isset($deal['lcv']) ? $deal['lcv'] : false, 
                            'other' => isset($deal['other']) ? $deal['other'] : false, 
                            'tractor' => isset($deal['tractor']) ? $deal['tractor'] : false, 
                        ]);
                    }
                }
                $asmnotify = collect([
                    'title' => 'Successfully added',
                    'body' =>  'You have successfully added '.$request['name']
                ]);
                sendNotification($user->id,$asmnotify);
                return response()->json(['status' => 'success','message' => 'Data inserted successfully.'], $this->successStatus);
            }
            return response(['status' => 'error', 'message' => 'No Record inserted.'],200);   
        }
        catch(\Exception $e)
        {
            return response()->json(['status' => 'error','message' => $e->getMessage() ], $this->internalError);
        }        
    }

    public function updateCustomerLocation(Request $request)
    {
        try
        { 
            $user = $request->user();
            $user_id = $user->id;

            if(Customers::where('id', $request['customer_id'])->update([
                'latitude' => isset($request['latitude'])? $request['latitude']:null,
                'longitude' => isset($request['longitude'])? $request['longitude']:null,
            ]))
            {
                return response()->json(['status' => 'success','message' => 'Data updated successfully.'], $this->successStatus);
            }
            return response(['status' => 'error', 'message' => 'No Record Updated.'],200);  
        }
        catch(\Exception $e)
        {
            return response()->json(['status' => 'error','message' => $e->getMessage() ], $this->internalError);
        }  
    }

    public function getRetailers(Request $request)
    {
        try
        { 
            $user = $request->user();
            $userids = getUsersReportingToAuth($user->id);
            // $user_id = $user->id;
            
            $pageSize = $request->input('pageSize');
            $search = $request['search'] ;
            $query = $this->customers->with('customeraddress','customerdetails','customertypes')
                            ->where(function($query) use($search, $userids) {
                                if(!empty($search))
                                {
                                    $query->where('name', 'like', "%{$search}%")->whereIn('executive_id', $userids)
                                    ->Orwhere('first_name', 'like', "%{$search}%")
                                    ->Orwhere('last_name', 'like', "%{$search}%")
                                    ->Orwhere('email', 'like', "%{$search}%")
                                    ->Orwhere('mobile', 'like', "%{$search}%");
                                }
                                $query->whereIn('executive_id', $userids);
                                $query->whereIn('customertype', ['2','3','4','5','6']);
                            })

                            // ->whereHas('customertypes', function($query) use($user){
                            //     $query->where('type_name', '=', 'retailer');
                            // })
                            ->select('id','name','first_name','last_name','mobile','email','profile_image','customer_code', 'latitude','longitude','customertype')
                            ->orderBy('name','asc');
                            //->latest();
            $db_data = (!empty($pageSize)) ? $query->paginate($pageSize) : $query->get();
            $data = collect([]);
            if($db_data->isNotEmpty())
            {
                foreach ($db_data as $key => $value) {
                    $data->push([
                        'customer_id' => isset($value['id']) ? $value['id'] : 0,
                        'name' => isset($value['name']) ? $value['name'] : '',
                        //'first_name' => isset($value['first_name']) ? $value['first_name'] : '',
                        //'last_name' => isset($value['last_name']) ? $value['last_name'] : '',
                        'mobile' => isset($value['mobile']) ? $value['mobile'] : '',
                        'email' => isset($value['email']) ? $value['email'] : '',
                        'profile_image' => isset($value['profile_image']) ? $value['profile_image'] : '',
                        //'customer_code' => isset($value['customer_code']) ? $value['customer_code'] : '',
                        //'totalamount' => isset($value['totalamount']) ? $value['totalamount'] : '',
                        //'totalpaid' => isset($value['totalpaid']) ? $value['totalpaid'] : '',
                        //'outstanding' => $value['totalamount']-$value['totalpaid'],
                        'address1' => isset($value['customeraddress']['address1']) ? $value['customeraddress']['address1'] : '',
                        'address2' => isset($value['customeraddress']['address2']) ? $value['customeraddress']['address2'] : '',
                        'latitude' => isset($value['latitude']) ? $value['latitude'] : '',
                        'longitude' => isset($value['longitude']) ? $value['longitude'] : '',
                        //'shop_image' => isset($value['customerdetails']['shop_image']) ? $value['customerdetails']['shop_image'] : '',
                        //'visiting_card' => isset($value['customerdetails']['visiting_card']) ? $value['customerdetails']['visiting_card'] : '',
                        'grade' => isset($value['customerdetails']['grade']) ? $value['customerdetails']['grade'] : '',
                        'visit_status' => isset($value['customerdetails']['visit_status']) ? $value['customerdetails']['visit_status'] : '',
                        'customer_type' => isset($value['customertypes']['customertype_name']) ? $value['customertypes']['customertype_name'] : '',
                        'distance' => '',
                    ]);
                }
                return response()->json(['status' => 'success','message' => 'Data retrieved successfully.','data' => $data ], $this->successStatus);
            }
            return response(['status' => 'error', 'message' => 'No Record Found.', 'data' => $data ],200);  
            
        }
        catch(\Exception $e)
        {
            return response()->json(['status' => 'error','message' => $e->getMessage() ], $this->internalError);
        }   
    }

    public function getDistributors(Request $request)
    {
         try
        { 
            $user = $request->user();
            $userids = getUsersReportingToAuth($user->reportingid);
            $pageSize = $request->input('pageSize');
            $query = $this->customers
                            // ->whereHas('customertypes', function($query) use($user){
                            //     $query->where('type_name', '=', 'distributor');
                            // })
                            ->with('customertypes','firmtypes')
                            ->whereHas('customertypes', function($query){
                                $query->where('type_name', '=', 'distributor')->orWhere('type_name', '=', 'Dealer');
                            })
                            ->whereIn('customertype', ['1'])
                            ->whereIn('executive_id', $userids)
                            ->select('id','name','first_name','last_name','mobile','email','profile_image','customer_code')->orderBy('name','asc');
            $db_data = (!empty($pageSize)) ? $query->paginate($pageSize) : $query->get();
            $data = collect([]);
            if($db_data->isNotEmpty())
            {
                foreach ($db_data as $key => $value) {
                    $data->push([
                        'customer_id' => isset($value['id']) ? $value['id'] : 0,
                        'name' => isset($value['name']) ? $value['name'] : '',
                        'first_name' => isset($value['first_name']) ? $value['first_name'] : '',
                        'last_name' => isset($value['last_name']) ? $value['last_name'] : '',
                        'mobile' => isset($value['mobile']) ? $value['mobile'] : '',
                        'email' => isset($value['email']) ? $value['email'] : '',
                        'profile_image' => isset($value['profile_image']) ? $value['profile_image'] : '',
                        'customer_code' => isset($value['customer_code']) ? $value['customer_code'] : '',
                    ]);
                }
                return response()->json(['status' => 'success','message' => 'Data retrieved successfully.','data' => $data ], $this->successStatus);
            }
            return response(['status' => 'error', 'message' => 'No Record Found.', 'data' => $data ],200);  
            
        }
        catch(\Exception $e)
        {
            return response()->json(['status' => 'error','message' => $e->getMessage() ], $this->internalError);
        }   
    }

    public function getCustomerList(Request $request)
    {
         try
        { 
            $user = $request->user();
            $user_id = $user->id;
            $pageSize = $request->input('pageSize');
            $query = $this->customers->with('customeraddress:customer_id,address1,address2','customerdetails:customer_id,grade,visit_status','customertypes')->select('id','name','first_name','last_name','mobile','email','profile_image','customer_code', 'latitude','longitude')->latest();
            $db_data = (!empty($pageSize)) ? $query->paginate($pageSize) : $query->get();
            $data = collect([]);
            if($db_data->isNotEmpty())
            {
                foreach ($db_data as $key => $value) {
                    $data->push([
                        'customer_id' => isset($value['id']) ? $value['id'] : 0,
                        'name' => isset($value['name']) ? $value['name'] : '',
                        'mobile' => isset($value['mobile']) ? $value['mobile'] : '',
                        //'first_name' => isset($value['first_name']) ? $value['first_name'] : '',
                        //'last_name' => isset($value['last_name']) ? $value['last_name'] : '',
                        'email' => isset($value['email']) ? $value['email'] : '',
                        'profile_image' => isset($value['profile_image']) ? $value['profile_image'] : '',
                        'customer_code' => isset($value['customer_code']) ? $value['customer_code'] : '',
                        //'totalamount' => isset($value['totalamount']) ? $value['totalamount'] : '',
                        //'totalpaid' => isset($value['totalpaid']) ? $value['totalpaid'] : '',
                        //'outstanding' => $value['totalamount']-$value['totalpaid'],
                        'address1' => isset($value['customeraddress']['address1']) ? $value['customeraddress']['address1'] : '',
                        'address2' => isset($value['customeraddress']['address2']) ? $value['customeraddress']['address2'] : '',
                        'latitude' => isset($value['latitude']) ? $value['latitude'] : '',
                        'longitude' => isset($value['longitude']) ? $value['longitude'] : '',
                        //'shop_image' => isset($value['customerdetails']['shop_image']) ? $value['customerdetails']['shop_image'] : '',
                        //'visiting_card' => isset($value['customerdetails']['visiting_card']) ? $value['customerdetails']['visiting_card'] : '',
                        'grade' => isset($value['customerdetails']['grade']) ? $value['customerdetails']['grade'] : '',
                        'visit_status' => isset($value['customerdetails']['visit_status']) ? $value['customerdetails']['visit_status'] : '',
                    ]);
                }
                return response()->json(['status' => 'success','message' => 'Data retrieved successfully.','data' => $data ], $this->successStatus);
            }
            return response(['status' => 'error', 'message' => 'No Record Found.', 'data' => $data ],200);  
            
        }
        catch(\Exception $e)
        {
            return response()->json(['status' => 'error','message' => $e->getMessage() ], $this->internalError);
        }   
    }

    public function getCustomerInfo(Request $request)
    {
         try
        { 
            $validator = Validator::make($request->all(), [
                'customer_id' => 'nullable|exists:customers,id',
            ]); 
            if ($validator->fails()) {
                return response()->json(['status' => 'error','message' => $validator->messages()->all()],$this->badrequest);
            }
            $user = $request->user();
            $user_id = $user->id;
            $fromdate = isset($request->fromDate) ? $request->fromDate : null;
            $todate = isset($request->toDate) ? $request->toDate :null;
            $customer_id = $request->input('customer_id');
            $orders = Order::where(function ($query) use($customer_id, $fromdate, $todate){
                $query->where('buyer_id', '=', $customer_id);
                if(!empty($fromdate) && !empty($todate))
                {
                    $query->whereBetween('order_date', [$fromdate, $todate]);
                }
            })
            ->select('grand_total','id','total_qty')->get();
            $sales = Sales::where(function ($query) use($customer_id, $fromdate, $todate){
                $query->where('buyer_id', '=', $customer_id);
                if(!empty($fromdate) && !empty($todate))
                {
                    $query->whereBetween('invoice_date', [$fromdate, $todate]);
                }
            })->select('grand_total')->get();

            $checkins = CheckIn::with('visitreports')->where('customer_id', '=', $customer_id)->select('checkin_date','checkin_time')->latest()->limit(10)->get();
            $last_order_date = Order::where('buyer_id', '=', $customer_id)->latest()->pluck('order_date')->first();
            $data = $this->customers->with('customerdetails','customeraddress','customerdocuments','surveys','surveys.fields','customeraddress.cityname','customeraddress.districtname','customeraddress.statename','customeraddress.pincodename','customertypes','customerdeals')->where('id', $customer_id)->select('id','name','first_name','last_name','mobile','email','profile_image','customer_code','customertype', 
                   DB::raw('(SELECT SUM(grand_total) FROM sales WHERE sales.buyer_id = customers.id) as totalamount'), 
                   DB::raw('(SELECT SUM(paid_amount) FROM sales WHERE sales.buyer_id = id) as totalpaid'))->first();
       
            $total_value = $orders->sum('grand_total');
            $total_qty = $orders->sum('total_qty');
            $beatinfo = Beat::whereHas('beatcustomers', function ($query) use($customer_id){
                                $query->where('customer_id','=',$customer_id);
                            })
                            ->select('beat_name','id')->first();
            $data['beat_name'] = isset($beatinfo['beat_name']) ? $beatinfo['beat_name'] : '';
            $data['beat_id'] = isset($beatinfo['id']) ? $beatinfo['id'] : null;
            $data['outstanding'] = $data['totalamount']-$data['totalpaid'];
            $data['total_order_value'] = $total_value;
            $data['total_order_quantity'] = $total_qty;
            $data['avg_order_value'] = ($total_value >= 1) ? number_format((float)$total_value/$orders->count(), 1, '.', '').' %'  : '';
            $data['avg_order_quantity'] = ($total_qty >= 1) ? number_format((float)$total_qty/$orders->count(), 1, '.', '').' %'  : '';
            $data['total_sales_value'] = $sales->sum('grand_total');
            $data['last_visited'] = (string)$checkins->pluck('checkin_date')->first();
            $data['last_order_date'] = isset($last_order_date) ? $last_order_date : '';
            $data['visited'] = $checkins;
            $data['email'] = isset($data['email']) ? $data['email'] : '';
            $data['customer_code'] = isset($data['customer_code']) ? $data['customer_code'] : '';
            $data['activities']= UserActivity::with('users')->where('customerid','=',$customer_id)->select('userid','time','description','type')->latest()->limit(5)->get();
            $data['tasks']= Tasks::with('users')->where('completed','=',0)->where('customer_id','=',$customer_id)->select('user_id','title','descriptions','datetime')->orderBy('datetime','asc')->limit(5)->get();
            unset($data['totalamount'] , $data['totalpaid']);
            $data['total_points'] = Wallet::where('customer_id','=',$customer_id)->where('transaction_type','=','Cr')->sum('points');
            $data['total_coupon_scan'] = Wallet::where('customer_id','=',$customer_id)->where('transaction_type','=','Cr')->sum('quantity');
            return response()->json(['status' => 'success','message' => 'Data retrieved successfully.','data' => $data ], $this->successStatus);
        }
        catch(\Exception $e)
        {
            return response()->json(['status' => 'error','message' => $e->getMessage() ], $this->internalError);
        }   
    }

    public function updateCustomerProfile(Request $request)
    {
        try
        { 
            $name = explode(" ", $request['full_name']);
            $request['last_name'] = isset($request['last_name']) ? $request['last_name'] : array_pop($name);
            $request['first_name'] = isset($request['first_name']) ? $request['first_name'] : implode(" ", $name);

            $validator = Validator::make($request->all(), [
                'name'      => 'required',
                // 'email'     => 'required|email|unique:customers,email,'.$request->customer_id,
                // 'mobile'    => 'required|unique:customers,mobile,'.$request->customer_id,
            ]); 
            if ($validator->fails()) {
                return response()->json(['status' => 201, 'msg' =>  implode(', ',$validator->messages()->all())], 200); 
            }

            if ($customer = Customers::where('id','=',$request->customer_id)->update([
                'name'      => isset($request->name) ? $request->name : '',
                'first_name'=> isset($request->first_name) ? $request->first_name : '',
                'last_name' => isset($request->last_name) ? $request->last_name : '',
                'email'     => isset($request->email) ? $request->email : null,
                'mobile'    => isset($request->mobile) ? $request->mobile : null,
                'latitude'  => isset($request->latitude) ? $request->latitude : null,
                'longitude' => isset($request->longitude) ? $request->longitude : null,
                'gender'    => isset($request->gender) ? $request->gender : '',
                'firmtype'  => isset($request->firmtype) ? $request->firmtype : null,
            ])) {

                Address::updateOrCreate(['id'   =>  $request['address_id'],'customer_id'   =>  $request->customer_id],[
                    'active'    => 'Y',
                    'customer_id'   =>  $request['customer_id'],
                    'address1' => isset($request['address1']) ? $request['address1'] :'',
                    'address2' => isset($request['address2']) ? $request['address2'] :'',
                    'landmark' => isset($request['landmark']) ? $request['landmark'] :'',
                    'locality' => isset($request['locality']) ? $request['locality'] :'',
                    'country_id' => isset($request['country_id']) ? $request['country_id'] :null,
                    'state_id' => isset($request['state_id']) ? $request['state_id'] :null,
                    'district_id' => isset($request['district_id']) ? $request['district_id'] :null,
                    'city_id' => isset($request['city_id']) ? $request['city_id'] :null,
                    'pincode_id' => isset($request['pincode_id']) ? $request['pincode_id'] :null,
                    'zipcode' => isset($request['zipcode']) ? $request['zipcode'] :'',
                    'created_by' => $request->user()->id,
                    'updated_at' => getcurentDateTime()
                ]);

                // if($request->file('shopimage')){
                //     $image = $request->file('shopimage');
                //     $filename = 'customer';
                //     $request['shop_image'] = fileupload($image, $this->path, $filename);
                // }

                if($request->file('gstin_image')){
                    $image = $request->file('gstin_image');
                    $filename = 'customer';
                    $gstinimagepath = fileupload($image, $this->path.'/gstin', $filename);
                    Attachment::updateOrCreate(['document_name'   =>  'gstin','customer_id'   =>  $request->customer_id],[
                        'active'        => 'Y',
                        'file_path'     => $gstinimagepath,
                        'document_name' =>  'gstin', 
                        'customer_id' => $request['customer_id'],
                        'updated_at' => getcurentDateTime()
                    ]);
                }

                if($request->file('pan_image')){
                    $image = $request->file('pan_image');
                    $filename = 'customer';
                    $panimagepath = fileupload($image, $this->path.'/pan', $filename);
                    Attachment::updateOrCreate(['document_name'   =>  'pan','customer_id'   =>  $request->customer_id],[
                        'active'        => 'Y',
                        'file_path'     => $panimagepath,
                        'document_name' =>  'pan', 
                        'customer_id' => $request['customer_id'],
                        'updated_at' => getcurentDateTime()
                    ]);
                }

                if($request->file('aadhar_image')){
                    $image = $request->file('aadhar_image');
                    $filename = 'customer';
                    $aadharimagepath = fileupload($image, $this->path.'/aadhar', $filename);
                    Attachment::updateOrCreate(['document_name'   =>  'aadhar','customer_id'   =>  $request->customer_id],[
                        'active'        => 'Y',
                        'file_path'     => $aadharimagepath,
                        'document_name' =>  'aadhar', 
                        'customer_id' => $request['customer_id'],
                        'updated_at' => getcurentDateTime()
                    ]);
                }

                if($request->file('other_image')){
                    $image = $request->file('other_image');
                    $filename = 'customer';
                    $otherimagepath = fileupload($image, $this->path.'/other', $filename);
                    Attachment::updateOrCreate(['document_name'   =>  'aadhar','customer_id'   =>  $request->customer_id],[
                        'active'        => 'Y',
                        'file_path'     => $otherimagepath,
                        'document_name' =>  'other', 
                        'customer_id' => $request['customer_id'],
                        'updated_at' => getcurentDateTime()
                    ]);
                }

                if($request->file('visiting_card')){
                    $image = $request->file('visiting_card');
                    $filename = 'customer';
                    $request['visiting_image'] = fileupload($image, $this->path.'/visiting', $filename);
                    CustomerDetails::updateOrCreate(['customer_id'   =>  $request->customer_id],[
                        'visiting_card'  =>  isset($request['visiting_image'])? $request['visiting_image']:'',
                    ]);
                }

                if($request->file('shop_image')){
                    $image = $request->file('shop_image');
                    $filename = 'customer';
                    $request['shop_image'] = fileupload($image, $this->path.'/shopimage', $filename);
                    CustomerDetails::updateOrCreate(['customer_id'   =>  $request->customer_id],[
                        'shop_image'  =>  isset($request['shop_image'])? $request['shop_image']:'',
                    ]);
                }

                CustomerDetails::updateOrCreate(['customer_id'   =>  $request->customer_id],[
                    'active'        => 'Y',
                    'customer_id'   => isset($request['customer_id'])? $request['customer_id']:null,
                    'gstin_no'      => isset($request['gstin_no'])? ucfirst($request['gstin_no']):'',
                    'pan_no'        => isset($request['pan_no'])? ucfirst($request['pan_no']):'',
                    'aadhar_no'     => isset($request['aadhar_no'])? ucfirst($request['aadhar_no']):'',
                    'otherid_no'    => isset($request['otherid_no'])? ucfirst($request['otherid_no']):'',
                    'enrollment_date' => isset($request['enrollment_date'])? $request['enrollment_date']:null,
                    'approval_date'  => isset($request['approval_date'])? $request['approval_date']:null,
                    'grade' => isset($request['grade'])? $request['grade'] : '',
                    'visit_status' => isset($request['status_type'])? $request['status_type'] : '',
                    'updated_at'    => getcurentDateTime(),
                ]);
                if($request['beat_id'])
                {
                    $beats = BeatCustomer::updateOrCreate(['beat_id'   =>  $request['beat_id'],'customer_id'   =>  $request->customer_id],[
                        'active' => 'Y',
                        'beat_id' => $request['beat_id'],
                        'customer_id' => $request['customer_id'],
                        'updated_at' => getcurentDateTime(),
                    ]);
                }
                if($request['survey'])
                {
                    $surveyqus = json_decode($request['survey'], true);
                    foreach ($surveyqus as $key => $rows) {

                        SurveyData::updateOrCreate(['field_id'   =>  $rows['field_id'],'customer_id'   =>  $request->customer_id],[
                            'customer_id'   => isset($request['customer_id'])? $request['customer_id']:null,
                            'field_id' => !empty($rows['field_id']) ? $rows['field_id'] :null,
                            'value' => !empty($rows['value']) ? $rows['value'] :'',
                            'created_by' => !empty($request['created_by']) ? $request['created_by'] :$request->user()->id,
                            'updated_at' => getcurentDateTime(),
                        ]);
                    }
                }
                if($request['dealing'])
                {
                    $dealings = json_decode($request['dealing'], true);
                    foreach ($dealings as $key => $deal) {
                        DealIn::updateOrCreate([
                            'customer_id' => $request['customer_id'],
                            'types' => $deal['types']
                            ],[
                            'customer_id'   => !empty($request['customer_id'])? $request['customer_id']:null,
                            'types' => !empty($deal['types']) ? $deal['types'] :'',
                            'hcv' => !empty($deal['hcv']) ? $deal['hcv'] : false, 
                            'mav' => !empty($deal['mav']) ? $deal['mav'] : false, 
                            'lmv' => !empty($deal['lmv']) ? $deal['lmv'] : false, 
                            'lcv' => !empty($deal['lcv']) ? $deal['lcv'] : false, 
                            'other' => !empty($deal['other']) ? $deal['other'] : false, 
                            'tractor' => !empty($deal['tractor']) ? $deal['tractor'] : false, 
                        ]);
                    }
                }
                if($request->file('image')){
                    $image = $request->file('image');
                    // $filename = 'punchin_'.autoIncrementId('Attendance', 'id');
                    $filename = 'customer';
                    $request['profile_image'] = fileupload($image, $this->path, $filename);
                    Customers::where('id','=',$request->customer_id)->update([
                        'profile_image'      => $request['profile_image']
                    ]);
                }
                return response()->json(['status' => 200, 'msg' => 'Customer Update Successfully','data' => $customer ], 200); 
            }

            return response()->json(['status' => 201, 'msg' => 'Error in user registertion' ], 200);
        }
        catch(\Exception $e)
        {
            return response()->json(['status' => 201, 'msg' => $e->getMessage() ], 500);
        } 

    }
}
